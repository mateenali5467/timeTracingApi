/**
 * Imported Libraries
 */
 const express = require('express');
 const logger = require('morgan');
 const bodyParser = require('body-parser');
 const cors = require('cors');
 const util = require('util');
 const mongoose = require('mongoose');
 const passport = require('passport');
 const path = require('path');
 const dotenv = require('dotenv');
 const colors = require('colors')
 
 /**
  * Configuration
  */
 dotenv.config({ path: './app/utils/config/config.env' });
 require('./app/utils/config/database')();
 
 /**
  * Server Configuration
  */
 // init app
 const app = express();
 // body-parser middleware
 app.use(bodyParser.json());
 // dev log middleware
 if (process.env.NODE_ENV === 'development') {
	 app.use(logger('dev'));
 }
 app.use(cors());
 app.use((req, res, next) => {
	 res.header("Access-Control-Allow-Origin", "*");
	 res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	 res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
	 res.setHeader('Access-Control-Allow-Credentials', true);
	 next()
 });
 
 /**
  * Managing Routes
  */
 app.get('/App', function (req, res) {
	 res.json({
		 "Tutorial": "Build REST API with Node.JS & MongoDB!!"
	 });
 });
//  app.get("/Email", function (req, res) {
// 	 res.render(cancelEmail.ejs);
//  });
 
 /**
  * Routes
  */
 // Admin APIs Route
 const userRoutes = require('./app/routes/user');
 const employeeRoutes = require('./app/routes/employee');
 const customerRoutes = require('./app/routes/customer');
 const projectRoutes = require('./app/routes/project');
 const taskRoutes = require('./app/routes/task');
 app.use('/v1/auth', userRoutes);
 app.use('/v1/employee', employeeRoutes);
 app.use('/v1/customer', customerRoutes);
 app.use('/v1/project', projectRoutes);
 app.use('/v1/task', taskRoutes);
 
 
 
  
 /**
  * Impliment Authenticate
  */
 require('./app/middlewares/verifyToken')(passport); // to verify token
 
 /**
  * Handling 404, 500 Errors
  */
 app.use(function (err, req, res, next) {
	 if (err.status === 404)
		 res.status(404).json({
			 message: "Not found"
		 });
	 else
		 res.status(500).json({
			 message: "Internal Server Error",
			 err: util.inspect(err)
		 });
 });
 
 
 /**
  * Set Static Client Folder
  */
 app.use(express.static(path.join(__dirname, 'build')));
 
 //Angular build mode
//  app.get('/', (req, res) => {
// 	 res.sendFile(path.join(__dirname + '/build/index.html'));
//  })
 
 
 /**
  * Server Connection
  */
 const PORT = process.env.PORT || 6000;
 // // Local Server
 const server = app.listen(PORT, function () {
	 console.log(`${process.env.NODE_ENV} Application running locally at  http://localhost:${PORT}`.yellow.bold);
 });
 
 // // secure server
//  let server = https.createServer(options, app)
//  server.listen(PORT, err => {
//  	console.log(`${process.env.NODE_ENV} Secure Application running at  https://everlio.com:${PORT}`.yellow.bold);
//  });
 
 
 /**
  * Set Static Client Folder
  */
//  app.use(express.static(path.join(__dirname, 'build')));
 
//  //Angular build mode
//  app.get('/', (req, res) => {
// 	 res.sendFile(path.join(__dirname + '/build/index.html'));
//  }) 
