/*jshint esversion: 6 */
const express = require("express");
const router = express.Router();
const passport = require("passport");
const config = require("../utils/config/index");
const passportJWT = passport.authenticate("admin", { session: false });
const projectController = require("../controllers/project.controller");

router.post("/create/:id", projectController.createProject);
router.get("/", projectController.getAllProjects);
router.get("/:id", projectController.getProjectsById);
router.delete("/:id", projectController.deleteProjectsById);
router.put("/:id", projectController.updateProjectById);

module.exports = router;
