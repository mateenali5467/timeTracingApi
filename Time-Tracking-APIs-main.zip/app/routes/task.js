/*jshint esversion: 6 */
const express = require("express");
const router = express.Router();
const passport = require("passport");
const config = require("../utils/config/index");
const passportJWT = passport.authenticate("admin", { session: false });
const taskController = require("../controllers/task.controller");

router.post("/create/:id", taskController.createTask);
// router.get('/',taskController.getAllTask);
router.get("/:id", taskController.getTaskById);
router.get("/emp/:id", taskController.getTaskByEmployeeId);
router.delete("/:id", taskController.deleteTaskById);
router.put("/:id", taskController.updateTaskById);

module.exports = router;
