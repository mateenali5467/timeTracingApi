/*jshint esversion: 6 */
const express = require('express');
const router = express.Router();
const passport = require('passport');
const config = require('../utils/config/index')
const passportJWT = passport.authenticate('admin', { session: false });
const userController = require('../controllers/user.controller');

router.post('/create',userController.createUser);
router.post('/login', userController.userLogin);

module.exports = router; 
 