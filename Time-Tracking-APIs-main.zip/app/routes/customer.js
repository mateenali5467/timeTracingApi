/*jshint esversion: 6 */
const express = require("express");
const router = express.Router();
const passport = require("passport");
const config = require("../utils/config/index");
const passportJWT = passport.authenticate("admin", { session: false });
const customerController = require("../controllers/customer.controller");

router.post("/create/:id", customerController.createCustomer);
router.get("/", customerController.getAllCustomer);
router.get("/:id", customerController.getCustonerById);
router.get("/emp/:id", customerController.getCustonerBySuperAdmin);
router.delete("/:id", customerController.deleteCustomerById);
router.put("/:id", customerController.updateCustomer);

module.exports = router;
