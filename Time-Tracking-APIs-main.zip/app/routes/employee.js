/*jshint esversion: 6 */
const express = require("express");
const router = express.Router();
const passport = require("passport");
const config = require("../utils/config/index");
const passportJWT = passport.authenticate("admin", { session: false });
const employeeController = require("../controllers/employee.controller");

router.post("/create/:id", employeeController.createEmployee);
router.get("/", employeeController.getAllEmployee);
router.get("/:id", employeeController.getEmployeeById);
router.post("/:id", employeeController.deleteEmployeeById);
router.put("/:id", employeeController.updateEmployeeById);

// router.get('/',passportJWT,employeeController.getAllEmployee);
// router.post('/update_role',passportJWT,employeeController.updateRoles);
// router.put('/update_Role/:id',passportJWT,employeeController.updateRole);

module.exports = router;
