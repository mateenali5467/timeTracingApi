const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ExpensesSchema = Schema({
    Description: {
        type: String,
        required: false,
        
    },
    ExpenseSheetdate: {
        type: String,
        required: false,
        
    },
    Title: {
        type: String,
        required: false,
        
    },
    UserId: {
        type: Number,
        required: false,
        
    },
    SortBy: {
        type: Boolean,
        required: false,
        
    },
    User: {
        type: String,
        required: false,
        
    },
    Limit: {
        type: Number,
        required: false,
        
    },
    Offset: {
        type: Number,
        required: false,
        
    },
    Verbose: {
        type: String,
        required: false,
        
    },
   
}
,{
    timestamps: true
})

module.exports = mongoose.model('expenses', ExpensesSchema)








// Description
// : 
// "ZXCDFFR"
// ExpenseSheetDate
// : 
// "2023-08-09"
// Title
// : 
// "TASK"
// UserID
// : 
// "4o9Qb3Oy_IdHN3wdDs3qBgw2"
// CTLegacyScramble
// : 
// "true"
// SortBy
// : 
// "User"
// UserIsActive
// : 
// "true"
// limit
// : 
// 50
// offset
// : 
// 0
// verbose
// : 
