const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const CustomerSchema = Schema({

    CustomerName: {
        type: String,
        required: true,
    },
    CreatedBy: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'employee'
    },
    CompanyId: {
        type: String,
        required: false,
    },
    BillingRate: {
        type: Number,
        required: false,
        
    },
    IsActive: {
        type: String,
        required: false,
        
    },
    CustomFields: {
        type: String,
        required: false,
        
    },
    IsDeleted: {
        type: String,
        required: false,
        
    },
    IsElligibleTimeOfAllLocation: {
        type: String,
        required: false,
        
    },
    IsLocked: {
        type: Number,
        required: false,
        
    },
    Notes: {
        type: String,
        required: false,
        
    },
    ListDisplayText: {
        type: String,
        required: false,
        
    },
    LoadedProperties: {
        type: String,
        required: false,
        
    },
    ScrambledClientId: {
        type: Number,
        required: false,
        
    },
    SecondaryBillingRateMode: {
        type: Number,
        required: false,
        
    },
    
}
,{
    timestamps: true
})

module.exports = mongoose.model('customer', CustomerSchema);