const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProjectSchema = Schema(
    {
        ProjectName: {
            type: String,
            required: true,
        },
        ProjectNumber: {
            type: Number,
            required: true,
        },
        CustomerId: {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: 'customer'
        },
        AssignToEmployee: [],
        BillingRate: {
            type: Number,
            required: false,
        },
        ManagedByEmployeeId: {
            type: mongoose.Schema.Types.ObjectId,
            required: false,
            ref: 'employee'
        },
        StartDate: {
            type: Date,
            required: false,
        },
        EndDate: {
            type: Date,
            required: false,
        },
        IsActive: {
            type: String,
            required: false,
        },
        ProjectEstimation: {
            type: String,
            required: false,
        },
        LifeTimeBudget: {
            type: String,
            required: false,
        },
        Notes: {
            type: String,
            required: false,
        },
        IsBillable: {
            type: String,
            required: false,
        },
        IsDeleted: {
            type: String,
            required: false,
        },
        IselligibleTimeOfAllLocation: {
            type: String,
            required: false,
        },
        IsJobElligibleRp: {
            type: String,
            required: false,

        },
        IsNonAllLocatedJob: {
            type: String,
            required: false,

        },
        IsSubjectToApproval: {
            type: String,
            required: false,

        },
        ListDisplayText: {
            type: String,
            required: false,

        },
        LoadedProperties: {
            type: String,
            required: false,
        },
        SecondaryBillingRateMode: {
            type: Number,
            required: false,
        },
        UseCompanyBillingRate: {
            type: String,
            required: false,
        },
        ScrambleJobId: {
            type: String,
            required: false,
        },
        CreatedBy: {
            type: mongoose.Schema.Types.ObjectId,
            required: false,
            ref: 'employee'
        },
    },{
        timestamps: true
    })

module.exports = mongoose.model('project', ProjectSchema)
















// AcctJobID
// : 
// null
// AvailableDivisions
// : 
// null
// AvailableTasks
// : 
// null
// AvailableUsers
// : 
// null
// BillingRate
// : 
// 150
// Client
// : 
// null
// ClientID
// : 
// "2Ou6dYHz-OGA"
// CompanyID
// : 
// "2A02k3nrfEyE"
// CustomFields
// : 
// null
// EndDate
// : 
// ""
// IsActive
// : 
// true
// IsBillable
// : 
// true
// IsDeleted
// : 
// false
// IsEligibleTimeOffAllocation
// : 
// false
// IsJobEligibleRP
// : 
// false
// IsNonAllocatedJob
// : 
// false
// IsSubjectToApproval
// : 
// false
// JobEstimation
// : 
// null
// JobID
// : 
// null
// JobName
// : 
// "project3"
// JobNumber
// : 
// "p-3"
// LifeTimeBudget
// : 
// ""
// LifetimeBudget
// : 
// null
// ListDisplayName
// : 
// ""
// ListDisplayText
// : 
// ""
// LoadedProperties
// : 
// 1
// ManagedByUserID
// : 
// null
// Notes
// : 
// null
// SecondaryBillingRateMode
// : 
// 1
// StartDate
// : 
// ""
// UseCompanyBillingRate
// : 
// true
// scrambleJobID
// : 
// null