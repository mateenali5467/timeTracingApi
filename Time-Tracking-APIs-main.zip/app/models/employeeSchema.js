const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const EmployeeSchema = Schema({
    FirstName: {
        type: String,
        required: true
    },
    LastName: {
        type: String,
        required: true
    },
    Email: {
        type: String,
        required: true,
    },
    Password: {
        type: String,
        required: true,
    },
    isSuperAdmin: {
        type: Boolean,
        required: false
    },
    SuperAdminId: {
        type: mongoose.Schema.Types.ObjectId,
        required: false,
        ref:'user'
    },
    Role:{
        type: String,
        required: false,
    },
    EstimationCost:{
        type: String,
        required: false,
    },
    EmployeeType: {
        type: String,
        required: false
    },
    StartDate: {
        type: Number,
        required: false,
    },
    EndDate: {
        type: Number,
        required: false,
    },
    Division: {
        type: String,
        required: false,
    },
    CreatedBy: {
        type: mongoose.Schema.Types.ObjectId,
        required: false,
        ref:'user'
    },
    DefaultTask: {
        type: String,
        required: false,
    },
    EmployeeNumber: {
        type: Number,
        required: false,
    },
    AccountingPackage: {
        type: String,
        required: false,
    },
    Status: {
        type: Boolean,
        required: false,
    },
    Notes: {
        type: String,
        required: false,
    },
    Permissions: [
        {
            MyWorkSpace: [
                {
                    name: {
                        type: String,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    create: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    edit: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    read: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    delete: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                },
            ],
            Administrator: [
                {
                    name: {
                        type: String,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    create: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    edit: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    read: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    delete: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                },
            ],
            Reports: [
                {
                    name: {
                        type: String,
                        trim: true,
                        default: false,
                        required: false,
                    },
                    create: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    edit: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    read: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                    delete: {
                        type: Boolean,
                        default: false,
                        trim: true,
                        required: false,
                    },
                },
            ],
        },
    ],
},
    {
        timestamps: true
    });
module.exports = mongoose.model('employee', EmployeeSchema);