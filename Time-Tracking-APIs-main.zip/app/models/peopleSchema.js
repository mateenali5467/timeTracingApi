// const mongoose = require('mongoose');
// const Schema = mongoose.Schema;

// const PeopleSchema = Schema({
//     FullName: {
//         type: String,
//         required: false,
        
//     },
//     EmailAddress: {
//         type: String,
//         required: false,
        
        
//     },
//     startDate: {
//         type: Number,
//         required: false,
        
//     },
//     EndDate: {
//         type: Number,
//         required: false,
        
//     },
//     Role: {
//         type: String,
//         required: false,
        
//     },
//     Employment: {
//         type: String,
//         required: false,
        
//     },
//     Division: {
//         type: String,
//         required: false,
        
//     },
//     DefaultTask: {
//         type: String,
//         required: false,
        
//     },
//     EmployeeNumber: {
//         type: Number,
//         required: false,
        
//     },
//     AccountingPackage: {
//         type: String,
//         required: false,
        
//     },
//     PersonId: {
//         type: Number,
//         required: false,
        
//     },
//     Status: {
//         type: String,
//         required: false,
        
//     },
//     Notes: {
//         type: String,
//         required: false,
        
//     },
// }
// ,{
//     timestamps: true
// })

// module.exports = mongoose.model('people', PeopleSchema)