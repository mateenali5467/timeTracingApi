const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const TimeActivitySchema = Schema({
    UserId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'role'
    },
    TaskId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'task'
    },
    StartTime: {
        type: Date,
        required: true,
        ref: 'role'
    },
    EndTime: {
        type: Date,
        required: true,
        ref: 'role'
    },
    DurationMinutes:{
        type: Number,
        required: false,
    },
    CustomerProjectID:{
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'customerproject'
    },
    TaskId:{
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'task'
    },
    InternalNotes:{
        type:String,
        required: false
    },
    EmployeeID:{
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'role'
    },
    IsTime:{
        type: Boolean,
        required: false
    },  
    isAdmin:{
        type: Boolean,
        required: false
    }
},{
    timestamps: true
})

module.exports = mongoose.model('timeActivities', TimeActivitySchema)