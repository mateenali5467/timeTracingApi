// const mongoose = require('mongoose');
// const schema = mongoose.Schema;

// const companyInfo = schema({
//     {
//         HomeCompanyID: {
//             type: String,
//             required: true
//         },
//         listInvoiceTemplate: {
//             type: String,
//             required: false,
//         },
//         listPayment:{
//             type: String,
//             required: false,
//         },
//         PaymemtTermsID:{
//             type: Number,
//         },
//         Description:{
//             type: String,
//             required: false,
//         },
//         InvoiceFrequency:{
//             type: Number,
            
//         },
//         CombineTE:{
//             type: Boolean,
//             required: false,
//         },
//         SplitInvoiceBy:{
//             type: Number,
//             required: false,
//         },
//         ExpenseGrouping:{
//             type: Number,
//             required: false,
//         },
//         UseClassesInTS:{
//             type: Boolean,
//             required: false,
//         },
//         TimeSheetFrequency:{
//             type: Number,
//             required: false,
//         },
//         LastDayOfWeek:{
//             type: Number,
//             required: false,
//         },
//         ShowStartEndTime:{
//             type: Boolean,
//             required: false,
//         },
//         TimerInterval:{
//             type: Number,
//             required: false,
//         },
//         ShowCopyFromLastInTS:{
//             type: Boolean,
//             required: true,
//         },
//         CanApproverEditTimesheet:{
//             type: Boolean,
//             required: true,
//         },
//         CanApproverEditExpense:{
//             type: Boolean,
//             required: true,
//         },
//         MinHoursForTS1:{
//             type: String,
//             required: false,
//         },
//         MinHoursForTS:{
//             type: Number,
//             required: true,
//         }
//         AddEmpNameToTSNotes:{
//             type: Boolean,
//             required: true,
//         },
//         DefaultBillableStatusTS:{
//             type: Number,
//             required: true,
//         },
//         BwTsStDate:{
//             type: String,
//             required: true,
//         },
//         AllowModifictions4BP:{
//             type: String,
//             required: true,
//         },
//         CanAdminRejectTS4BP:{
//             type: Boolean,
//             required: true,
//         },
//         Message4BlockedPeriod:{
//             type: String,
//             required: true,
//         },
//         UseClassesInExp:{
//             type: Boolean,
//             required: false,
//         },
//         MerchantLexicon:{
//             type: String,
//             required: true,
//         },
//         PaidByMeLexicon:{
//             type: String,
//             required: true,
//         },
//         PaidByCompanyLexicon:{
//             type: Boolean,
//             required: true,
//         },
//         LimitExpToAssignedProjects:{
//             type: Boolean,
//             required: true,
//         },
//         LimitExpToAssignedClasses:{
//             type: Boolean,
//             required: false,
//         },
//         listBank:{
//             type: String,
//             required: false,
//         },
//         listTask:{
//             type: String,
//             required: false,
//         },
//         customtask:{
//             type: String,
//             required: false,
//         },
//         listCurrency:{
//             type: String,
//             required: false,
//         },
//         SendCCEntryAsPerItem:{
//             type: Boolean,
//             required: false,
//         },
//         AddExpIconDescToExp:{
//             type: Boolean,
//             required: true,
//         },
//         AddExpDateToExp:{
//             type: Boolean,
//             required: true,
//         },
//         AddEmpNameToExp:{
//             type: String,
//             required: false,
//         },
//         SendCompanyPaidToQB:{
//             type: String,
//             required: true,
//         },
//         PrefferedBankName:{
//             type: String,
//             required: false,
//         },
//         ShowAttendees:{
//             type: Boolean,
//             required: false,
//         },
//         TimeApprovedBy:{
//             type: Number,
//             required: true,
//         },
//         ExpApprovedBy:{
//             type: Boolean,
//             required: true,
//         },
//         CanTimeOffBeApproved:{
//             type: Boolean,
//             required: true,
//         },
//         ReqCmnts4TSChanges:{
//             type: Boolean,
//             required: true,
//         },
//         CanEmpSignTimesheets:{
//             type: Boolean,
//             required: false,
//         },
//         CanAppSignTimesheets:{
//             type: Boolean,
//             required: false
//         },
//         CanEmpSignExpenses:{
//             type: Boolean,
//             required: false,
//         },
//         CanAppSignExpenses:{
//             type: Boolean,
//             required: false,
//         },
//         TimesheetDownloadClass:{
//             type: Number,
//             required: true,
//         },
//         ExpenseDownloadClass:{
//             type: Number,
//             required: true,
//         },
//         TimesheetLastSyncDate:{
//             type: String,
//             required: true,
//         },
//         ExpenseLastSyncDate:{
//             type: String,
//             required: true,
//         },
//         CustomerLastSyncDate:{
//             type: String,
//             required: true,
//         },
//          VendorLastSyncDate:{
//             type: String,
//             required: true,
//         },
//            EmployeeLastSyncDate:{
//             type: String,
//             required: true,
//         },
//         GLAccountsLastSyncDate:{
//             type: String,
//             required: true,
//         },
//         TaskLastSyncDate:{
//             type: String,
//             required: true,
//         },
//         ClassesLastSyncDate:{
//             type: String,
//             required: true,
//         },
//         TimePayrollItemID:{
//             type: String,
//             required: true,
//         },
//         TimeSalariedPayrollItemID:{
//             type: String,
//             required: true,
//         },
//         TimeOwnerPayrollItemID:{
//             type: String,
//             required: true,
//         },
//         TimeOfficerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         HolidayPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         VacationPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         SickPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom1PayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom2PayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom3PayrollItemID:{
//             type: String,
//             required: false,
//         },
//         HolidaySalariedPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         VacationSalariedPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         SickSalariedPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom1SalariedPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom2SalariedPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom3SalariedPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         HolidayOfficerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         VacationOfficerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         SickOfficerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom1OfficerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom2OfficerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom3OfficerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         HolidayOwnerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         VacationOwnerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         SickOwnerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom1OwnerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom2OwnerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         Custom3OwnerPayrollItemID:{
//             type: String,
//             required: false,
//         },
//         listPayroll:{
//             type: String,
//             required: false,
//         },
//         listEmployee:{
//             type: String,
//             required: false,
//         },
//         listQBFiles:{
//             type: String,
//             required: false,
//         },
//         listQBLFiles:{
//             type: String,
//             required: false,
//         },
//         BringNewProjectsAsClosed:{
//             type: Boolean,
//             required: true,
//         },
//         SyncOtherNamesfromQB:{
//             type: Boolean,
//             required: false,
//         },
//         IntegratedAppID:{
//             type: Number,
//             required: true,
//         },
//         InactivateCustInEZ:{
//             type: Boolean,
//             required: true,
//         },
//         InactivateEmpInEZ:{
//             type: Boolean,
//             required: true,
//         },
//         InactivateItemInEZ:{
//             type: Boolean,
//             required: true,
//         },
//         InactivateGLInEZ:{
//             type: Boolean,
//             required: true,
//         },
//         InactivateVendInEZ:{
//             type: Boolean,
//             required: true,
//         },
//         InactivateClassInEZ:{
//             type: Boolean,
//             required: true,
//         },
//         SyncWithQuickBooks:{
//             type: Boolean,
//             required: true,
//         },
//         QuickBooksFilePath:{
//             type: Strin,
//             required: true,
//         }
//          listApplication:{
//             type: String,
//             required: false,
//         },
//         CompanyID:{
//             type: String,
//             required: true,
//         },
//         CompanyName:{
//             type: String,
//             required: true,
//         },
//         Phone:{
//             type: String,
//             required: true,
//         },
//         Fax:{
//             type: String,
//             required: true,
//         },
//         AltPhone:{
//             type: String,
//             required: true,
//         },
//         Email:{
//             type: String,
//             required: true,
//         },
//         WebSite:{
//             type: String,
//             required: true,
//         },
//         LogoFile:{
//             type: String,
//             required: true,
//         },
//         ContactLine1:{
//             type: String,
//             required: true,
//         },
//         ContactLine2:{
//             type: String,
//             required: true,
//         },
//         ContactLine3:{
//             type: String,
//             required: true,
//         },
//         ContactCity:{
//             type: String,
//             required: true,
//         },
//         ContactState:{
//             type: String,
//             required: true,
//         },
//         ContactZip:{
//             type: String,
//             required: true,
//         },
//         ContactCountry:{
//             type: String,
//             required: true,
//         },
//         RemitLine1:{
//             type: String,
//             required: true,
//         },
//         RemitLine2:{
//             type: String,
//             required: true,
//         },
//         RemitLine3:{
//             type: String,
//             required: true,
//         },
//         RemitCity:{
//             type: String,
//             required: true,
//         },
//         RemitState:{
//             type: String,
//             required: true,
//         },
//         RemitZip:{
//             type: String,
//             required: true,
//         },
//         RemitCountry:{
//             type: String,
//             required: true,
//         },
//         PayrollFrequency:{
//             type: Number,
//             required: true,
//         },
//         PayrollDay:{
//             type: Number,
//             required: true,
//         },
//         QBLastSyncDate:{
//             type: String,
//             required: true,
//         },
//         CurrentPayrollDate:{
//             type: String,
//             required: true,
//         },
//         PaymentTermsLastSyncDate:{
//             type: String,
//             required: true,
//         },
//         ExpenseDateLogicFlag:{
//             type: Boolean,
//             required: true,
//         },
//         PaymentTerms:{
//             type: String,
//             required: true,
//         },
//         CombinedOrSeperate:{
//             type: Boolean,
//             required: false,
//         },
//         InvoicingTerms:{
//             type: number,
//             required: true,
//         },
//         GroupingType:{
//             type: Number,
//             required: true,
//         },
//         InvoiceDetailLevel:{
//             type: Number,
//             required: true,
//         },
//         InvoiceTemplate:{
//             type: String,
//             required: true,
//         },
//         CombineProjects:{
//             type: Number,
//             required: true,
//         },
//         TimeItemDefault:{
//             type: String,
//             required: true,
//         },
//         ExpenseItemDefault:{
//             type: String,
//             required: true,
//         },
//         UseRateSheets:{
//             type: Boolean,
//             required: true,
//         },
//         InvoiceTemplateID:{
//             type: Number,
//             required: true,
//         },
//         PAOptional:{
//             type: Boolean,
//             required: true,
//         },
//         MarkupExpenses:{
//             type: Boolean,
//             required: true,
//         },
//         Switch1:{
//             type: Boolean,
//             required: true,
//         },
//         Switch2:{
//             type: Boolean,
//             required: false,
//         },
//         UseCurrency:{
//             type: Boolean,
//             required: false,
//         },
//         Switch4:{
//             type: Boolean,
//             required: false,
//         },
//         UseSalesTax:{
//             type: Boolean,
//             required: false,
//         },
//         Switch5:{
//             type: Boolean,
//             required: false,
//         },
//         Switch6:{
//             type: Boolean,
//             required: false,
//         },
//         PayrollMapping:{
//             type: Number,
//             required: true,
//         },
//         Switch8:{
//             type: Boolean,
//             required: false,
//         },
//         Switch9:{
//             type: Boolean,
//             required: false,
//         },
//         Switch10:{
//             type: Boolean,
//             required: false,
//         },
//         Switch11:{
//             type: Boolean,
//             required: false,
//         },
//         Switch12:{
//             type: Boolean,
//             required: false,
//         },
//         BaseCurrency:{
//             type: String,
//             required: true,
//         },
//         Custom1:{
//             type: String,
//             required: true,
//         },
//         Custom10:{
//             type: String,
//             required: true,
//         },
//         EmployeeLexicon:{
//             type: String,
//             required: true,
//         },
//         EmployeeLexiconP:{
//             type: String,
//             required: true,
//         },
//         CustomerLexicon:{
//             type: String,
//             required: true,
//         },
//         CustomerLexiconP:{
//             type: String,
//             required: true,
//         },
//         ProjectLexicon:{
//             type: String,
//             required: true,
//         },
//         ProjectLexiconP:{
//             type: String,
//             required: true,
//         },
//         TaskLexicon:{
//             type: String,
//             required: true,
//         },
//         TaskLexiconP:{
//             type: String,
//             required: true,
//         },
//         ClassLexicon:{
//             type: String,
//             required: true,
//         },
//         ClassLexiconP:{
//             type: String,
//             required: true,
//         },
//         ProjectsCol:{
//             type: String,
//             required: true,
//         },
//         ProjectColHeader:{
//             type: String,
//             required: true,
//         },
//         EmployeesCol:{
//             type: String,
//             required: true,
//         },
//         EmployeesColHeader:{
//             type: String,
//             required: true,
//         },
//         VendorsCol:{
//             type: String,
//             required: true,
//         },
//         VendorsColHeader:{
//             type: String,
//             required: true,
//         },
//         TasksCol:{
//             type: String,
//             required: true,
//         },
//         TasksColHeader:{
//             type: String,
//             required: true,
//         },
//         AccountsCol:{
//             type: String,
//             required: true,
//         },
//         AccountsColHeader:{
//             type: String,
//             required: true,
//         },
//         ClassesCol:{
//             type: String,
//             required: true,
//         },
//         ClassesColHeader:{
//             type: String,
//             required: true,
//         },
//         DateFormat:{
//             type: String,
//             required: true,
//         },
//         DropDownSearchPref:{
//             type: Number,
//             required: true,
//         },
//         AdminProxyApproverID:{
//             type: String,
//             required: false,
//         },
//         IsProjectListHrcy:{
//             type: Boolean,
//             required: true,
//         },
//         listDays:{
//             type: String,
//             required: false,
//         },
//         listClass: {
//             type: mongoose.Schema.Types.ObjectId,
//             required: false,
//             ref: 'classes'
//         },
//         Custom2:{
//             type: String,
//             required: false,
//         },
//         Custom3:{
//             type: String,
//             required: false,
//         },
//         Custom4:{
//             type: String,
//             required: false
//         },
//         Custom5:{
//             type: String,
//             required: false
//         },
//         Custom6:{
//             type: String,
//             required: false
//         },
//         Custom7:{
//             type: String,
//             required: false
//         },
//         Custom2Label:{
//             type: String,
//             required: false
//         },
//         Custom3Label:{
//             type: String,
//             required: false
//         },
//         Custom4Label:{
//             type: String,
//             required: false
//         },
//         Custom5Label:{
//             type: String,
//             required: false,
//         },
//         Custom6Label:{
//             type: String,
//             required: false,
//         },
//         Custom7Label:{
//             type: String,
//             required: false,
//         },
//         Status1:{
//             type: Boolean,
//             required: false
//         },
//         Status2:{
//             type: Boolean,
//             required: false
//         },
//         Status3{
//             type: Boolean,
//             required: false
//         },
//         "Status4": false,
//         "Status5": false,
//         "Status6": false,
//         "Allow": null,
//         "Date": null,
//         "Day": null,
//         "Day1": 0,
//         "PreferedLanguage": "en-US",
//         "PreferedFont": "OpenSansRegular",
//         "BackgroundImage": null,
//         "ThemeColors": "f2f2f2b80000b8000021070ab80000",
//         "TopBGImage": "img_trans.gif",
//         "UpdateDate": "2023-08-07T10:59:12.3515777+00:00",
//         "EnterTimeWithoutProject": false,
//         "EnterTimeWithoutTask": false,
//         "EnterTimeWithoutClass": false,
//         "EnterTimeWithoutDesc": false,
//         "EnterTimeWithoutPayroll": false,
//         "MinHoursAtEmployeeLevel": false,
//         "MinHoursCompletedEmp": false,
//         "TSkillswitch": false,
//         "AllowUserToEditUseRules": false,
//         "ShowDescription": false,
//         "ShowPONumber": false,
//         "ShowPayrollMapping": false,
//         "ShowTimesheetGrid": false,
//         "ShowToDo": false,
//         "AddMerchantToExp": false,
//         "AllowUsertoPauseTime": false,
//         "AllowMultiTimerSameTime": false,
//         "ShowMultipleTimer": false,
//         "ShowAllTimer": false,
//         "ShowTimeratEmployeeLevel": false,
//         "ShowTask": false,
//         "StartEndTimeOverlap": false,
//         "CopyTaskDescription": false,
//         "ShowProjectforExpense": false,
//         "ShowReceiptAmount": false,
//         "ShowExpDescription": false,
//         "ShowExpMerchant": false,
//         "EnterReceiptAmount": null
//     }
    
// })