// const mongoose = require('mongoose');
// const Schema = mongoose.Schema;
// const CustomerSchema = Schema({
//     CustomerProject: {
//         type: String,
//         required: true
//     },
//     SubjectProjectOf: {
//         type: String,
//         required: true
//     },
//     Description: {
//         type: String,
//         required: true
//     },
//     CreatedBy: {
//         type: mongoose.Schema.Types.ObjectId,
//         required: true,
//         ref: 'role'
//     },
   
// },
// {
//     timestamps: true
// });
// module.exports = mongoose.model('customerproject', CustomerSchema);

