const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const TimeOffSchema = Schema({
    Notes: {
        type: String,
        required: true,
        
    },
    RequestedByUserId: {
        type: String,
        required: false,  
    },

}
,{
    timestamps: true
})

module.exports = mongoose.model('timeoff', TimeOffSchema)



// Notes
// : 
// "dsfdff"
// RequestedByUserID
// : 
// "4o9Qb3Oy_IdHN3wdDs3qBgw2"
// TimeOffTypeID
// : 
