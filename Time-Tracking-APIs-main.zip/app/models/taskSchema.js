const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const TaskSchema = Schema({
    TaskName: {
        type: String,
        required: true
    },
    TaskNumber: {
        type: String,
        required: true
    },
    TaskType: {
        type: String,
        required: false
    },
    Notes:{
        type: String,
        required: false,
    },
    Class:{
        type: String,
        required: false
    },
    CostRate:{
        type: Number,
        required: false
    },
    TaxRate:{
        type: Number,
        required: false
    },
    Account:{
        type: String,
        required: false,
    },
    Billable:{
        type: Boolean,
        required: false
    },
    Taxable:{
        type: Boolean,
        required: false
    },
    BillRate:{
        type: String,
        required: false
    },
    Status:{
        type: String,
        required: false
    },
    ProjectId:{
        type: mongoose.Schema.Types.ObjectId,
        required: false,
        ref: 'project'
    },
    CreatedBy:{
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'employee'
    },

},
{
    timestamps: true
});

module.exports = mongoose.model('task', TaskSchema);