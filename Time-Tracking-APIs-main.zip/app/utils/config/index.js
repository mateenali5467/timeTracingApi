module.exports = {
    "hmWebUISecret": "Truetn App with nodejs mongodb#@$^$#%&^(*%%$%$%$)))(((((&5555554))))). I love Javascript",
    "adminsecret": "Truetn App with nodejs mongodb#@$^$#%&^(*%%$%$%$)))(((((&5555554))))). I love Javascript",
    "usersecret": "Users of Truetn App. @@#%&^%%$#@!#@#)))((*&^%%%%$%$%)). I love Javascript",
    "tempsecret": "Temp Tolen of Truetn App",
    "jwtExpiredTime": "1m",
    "saltRounds": 10,
    "aws": {
        "accessKeyId": "AKIAXEJ35FGFT476ZBEM",
        "secretAccessKey": "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",
        "region": "ap-south-1",
        "acl": "public-read",
        "bucket": "mytruetn",
        "resourcesFolder": {
            "H360": "truetn.Resources"
        }
    },
    "twitterAPI": {
        "consumer_key": "LPj5sbEMvBwEkG285rDVEfeYj",
        "consumer_secret": "wvKCpkXszNaVkOJfWKwfLdwF3rLfYUMb0anfv06hNM9L3yEOJ8",
        "access_token": "1332256516338970624-QKzAsBT7Mzal1FxW8DTNy0ACFKy44j",
        "access_token_secret": "fPZUsy2ZlXD0UujwzErkuldLaBaZeVdH4ZkIaQT2ggknM",
    },
    "kpopAPI": {
        "consumer_key": "kzuwGijzhLWqQ5Pflzh1WpSor",
        "consumer_secret": "LeOzhSdtB3whEBGzU1A5mUMLpWktAWL2mlFuG84Tc68Mk0oexW",
        "access_token": "1282161823232299009-Holl0EHq2doYTD555qcPUt0hJKxRil",
        "access_token_secret": "defQLv1Lx1sqKpF7YpAmONcUmJZZEn1hPhgCrF4e6dUbm",
    },
    "instagramAPI": {
        "consumer_id": "172883548003464",
        "consumer_secret": "0725222b21f80220630e062c64fe07c7",
        "access_token": "IGQVJVM0VGdXVUSGVGXzY2Mm9rTFZAGX1U0TFNyNlZAuWF91VmxzRXNGak56cHJmSXN6dEZA5WlctRFFJNVhlMlpmSDZAJSHd0azR1Ym1nTHNtSGx4RjJ2M0ZAXNVlDR0tMMUY5TVN6eDJCTW1ZAZAkVvOUdDMQZDZD",
    },
    "temporary":{
        "emailID": "temp@truetn.com",
        "password": "@!#_+)(*)TRUETN"

    }
   
}