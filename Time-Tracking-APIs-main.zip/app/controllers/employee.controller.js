const employeeModel = require("../models/employeeSchema");
const __res_ = require("../utils/helpers/send-response");
const config = require("../utils/config/index");
const asyncHandler = require("../middlewares/asyncHandler");
const keys = require("../utils/config/index");
const bcrypt = require("bcryptjs");
const generateUniquePassword = require("../utils/helpers/generateUniqueName");

module.exports = {
  createEmployee: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        const password = generateUniquePassword.generateUniquePassword();
        const newPassword = bcrypt.hashSync(password, keys.saltRounds);
        employeeModel
          .findOne({ Email: req.body.email })
          .exec(function (err, userInfo) {
            if (userInfo) {
              return __res_.out(req, res, {
                status: "found",
                statusCode: 200,
                message: "This Employeed Already Exit!!.",
              });
            } else {
              var empData = {
                FirstName: req.body.firstName,
                LastName: req.body.lastName,
                Email: req.body.email,
                Password: newPassword,
                isSuperAdmin: req.body.isSuperAdmin,
                Role: req.body.role,
                EmployeeType: req.body.employement,
                EstimationCost: req.body.estimationCost,
                Notes: req.body.notes,
                CreatedBy: req.params.id,
              };
              new employeeModel(empData).save().then((data) => {
                if (data) {
                  return __res_.out(req, res, {
                    status: true,
                    statusCode: 200,
                    message: "Employee Created Successfully!!",
                  });
                }
              });
            }
          });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },

  updateRoles: async function (req, res) {
    try {
      // let password = req.body.password;
      // let newPassword = bcrypt.hashSync(password, keys.saltRounds);
      employeeModel
        .updateOne(
          {
            _id: req.body._id,
          },
          {
            $set: {
              user_name: req.body.user_name,
              // "user_email": req.body.user_email,
              // "password": newPassword,
              // "role_type": req.body.role_type,
              permissions: [
                {
                  publishModule: {
                    name: req.body.permissions.MyWorkSpace.name,
                    create: req.body.permissions.MyWorkSpace.create,
                    edit: req.body.permissions.MyWorkSpace.edit,
                    read: req.body.permissions.MyWorkSpace.read,
                    delete: req.body.permissions.MyWorkSpace.delete,
                  },
                  draftModule: {
                    name: req.body.permissions.Administrator.name,
                    create: req.body.permissions.Administrator.create,
                    edit: req.body.permissions.Administrator.edit,
                    read: req.body.permissions.Administrator.read,
                    delete: req.body.permissions.Administrator.delete,
                  },
                  roleModule: {
                    name: req.body.permissions.Reports.name,
                    create: req.body.permissions.Reports.create,
                    edit: req.body.permissions.Reports.edit,
                    read: req.body.permissions.Reports.read,
                    delete: req.body.permissions.Reports.delete,
                  },
                },
              ],
            },
          }
        )
        .exec(async function (err, dta1) {
          if (err) {
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Update Role.",
              data: null,
            });
          } else {
            return __res_.out(req, res, {
              status: "success",
              statusCode: 200,
              message: "Role Updated Successfully!!",
            });
          }
        });
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },

  getAllEmployee: async function (req, res) {
    try {
      const page = parseInt(req.query.page) || 1; // Get the requested page number from query parameter
      const pageSize = 20; // Number of records per page
      const skipCount = (page - 1) * pageSize;

      // Get the total count of documents in the collection
      const totalCount = await employeeModel.countDocuments();

      employeeModel
        .find()
        .select("_id FirstName LastName Email EmployeeType")
        .skip(skipCount)
        .limit(pageSize)
        .exec((err, result) => {
          if (err) {
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Get Data.",
              data: null,
            });
          }

          return __res_.out(req, res, {
            status: "success",
            statusCode: 200,
            message: "Get Successfully!!",
            data: {
              totalRecords: totalCount,
              currentPage: page,
              pageSize: pageSize,
              records: result,
            },
          });
        });
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },

  getEmployeeById: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        employeeModel
          .find({ _id: req.params.id })
          .select("_id FirstName LastName Email EmployeeType")
          .exec((err, result) => {
            if (err)
              return __res_.out(req, res, {
                status: "error",
                statusCode: 500,
                message: "Unable to Get Data.",
                data: null,
              });
            return __res_.out(req, res, {
              status: "success",
              statusCode: 200,
              message: "Get Successfully!!",
              data: result,
            });
          });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },

  deleteEmployeeById: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        console.log("delete--->", req.params.id);
        employeeModel.deleteOne({ _id: req.params.id }).exec((err, result) => {
          if (err) {
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Delete Role.",
              data: null,
            });
          }
          {
            return __res_.out(req, res, {
              status: "success",
              statusCode: 200,
              message: "Employee Deleted Successfully!!",
              data: result,
            });
          }
        });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  updateEmployeeById: async function (req, res) {
    try {
      const employeeId = req.params.id;
      const updates = req.body;

      if (!employeeId) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      }

      const updatedEmployee = await employeeModel
        .findOneAndUpdate(
          { _id: employeeId },
          { $set: { ...updates, updatedAt: new Date() } },
          { new: true }
        )
        .exec();

      if (!updatedEmployee) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 404,
          message: "Employee not found.",
          data: null,
        });
      }

      return __res_.out(req, res, {
        status: "success",
        statusCode: 200,
        message: "Employee Updated Successfully!!",
        data: updatedEmployee,
      });
    } catch (e) {
      return __res_.out(req, res, {
        status: "error",
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
};
