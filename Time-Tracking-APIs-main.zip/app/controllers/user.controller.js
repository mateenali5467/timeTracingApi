const employeeModel = require('../models/employeeSchema');
const userModel = require('../models/userSchema');
const __res_ = require('../utils/helpers/send-response');
const config = require('../utils/config/index')
const asyncHandler = require('../middlewares/asyncHandler')
const keys = require('../utils/config/index');
const bcrypt = require('bcryptjs')
const activity = require('../utils/activities/activity.controller');
const jwt = require('jsonwebtoken');


module.exports = {
    createUser: async function (req, res) {
        try {
            const password = req.body.password;
            const newPassword = bcrypt.hashSync(password, keys.saltRounds);
            employeeModel.findOne({ Email: req.body.email }).exec(function (err, userInfo) {
                if (userInfo) {
                    return __res_.out(req, res, {
                        status: "found",
                        statusCode: 200,
                        message: "This User Already Exit!!.",
                    })
                } else {
                    let name = {
                        "SuperAdmin" : req.body.firstName
                    }
                    new userModel(name).save().then((resp) => {
                        if(resp){
                            var empData = {                                
                                "FirstName": req.body.firstName,
                                "LastName": req.body.lastName,
                                "Email": req.body.email,
                                "Password": newPassword,
                                "isSuperAdmin": req.body.isSuperAdmin,
                                "Role": req.body.role,
                                "EmployeeType": req.body.employeeType,
                                "EstimationCost": req.body.estimationCost,
                                "Notes": req.body.notes,
                                "CreatedBy": req.params.id
                            }
                            new employeeModel(empData).save().then((data) => {
                                if (data) {
                                    const payload = {
                                        _id: data._id,
                                        Email: data.Email,
                                        FirstName: data.FirstName,
                                    };
                                    jwt.sign(payload, keys.adminsecret, {
                                        expiresIn: keys.jwtExpiredTime
                                    }, (err, token) => {
                                        if (err) {
                                            return __res_.out(req, res, {
                                                status: "error",
                                                statusCode: 500,
                                                message: "Something went wrong",
                                                data: err
                                            });
                                        } else {
                                            token = `${token}`;
                                            return __res_.out(req, res, {
                                                status: true,
                                                statusCode: 200,
                                                message: "Singup Successfully!!",
                                                data: token,
                                            });
                                        }
                                    });
                                }
                            })
                        }
                    })
                    
                }
            })
        } catch (e) {
            return __res_.out(req, res, {
                status: true,
                statusCode: 500,
                message: "Internal server error!!!",
                data: e
            });
        }
    },

    // Will authenticate the user with email and password
    userLogin: function (req, res, next) {
        employeeModel.findOne({
            Email: req.body.email
        }).exec(
            function (err, userInfo) {
                if (err) {
                    return __res_.out(req, res, {
                        status: "error",
                        statusCode: 500,
                        data: err
                    });
                } else {
                    if (!userInfo) {
                        return __res_.out(req, res, {
                            status: "error",
                            statusCode: 404,
                            message: "User Does Not Exit!!",
                            data: null
                        })
                    } else if ((req.body.email === userInfo.Email) && (bcrypt.compareSync(req.body.password, userInfo.Password))) {
                        const payload = {
                            _id: userInfo._id,
                            Email: userInfo.Email,
                            FirstName: userInfo.FirstName,
                        };
                        jwt.sign(payload, keys.adminsecret, {
                            expiresIn: keys.jwtExpiredTime
                        }, (err, token) => {
                            if (err) {
                                return __res_.out(req, res, {
                                    status: "error",
                                    statusCode: 500,
                                    message: "Something went wrong",
                                    data: err
                                });
                            } else {
                                token1 = `${token}`;
                                return __res_.out(req, res, {
                                    status: true,
                                    statusCode: 200,
                                    message: "Login Successfully!!",
                                    data: token1,
                                });
                            }
                        });
                    } else {
                        return __res_.out(req, res, {
                            status: "error",
                            statusCode: 401,
                            message: "Invalid Credentials"
                        });
                    }
                }
            }
        );
    },
}