const taskModel = require("../models/taskSchema");
const __res_ = require("../utils/helpers/send-response");

module.exports = {
  createTask: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        taskModel
          .findOne({ TaskName: req.body.TaskName })
          .exec(function (err, userInfo) {
            if (userInfo) {
              return __res_.out(req, res, {
                status: "found",
                statusCode: 200,
                message: "This Task already exit with this name!!.",
              });
            } else {
              var empData = {
                TaskName: req.body.TaskName,
                TaskNumber: req.body.TaskNumber,
                Status: req.body.Status,
                ProjectId: req.body.ProjectId,
                Notes: req.params.Notes,
                CreatedBy: req.params.id,
              };
              new taskModel(empData).save().then((data) => {
                if (data) {
                  return __res_.out(req, res, {
                    status: true,
                    statusCode: 200,
                    message: "Task Created Successfully!!",
                  });
                }
              });
            }
          });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  // i have added pagination to below query as well in case if it is used in future
  //   getAllTask: async function (req, res) {
  //     try {
  //       const page = parseInt(req.query.page) || 1; // Get the requested page number from query parameter
  //       const pageSize = 20; // Number of records per page
  //       const skipCount = (page - 1) * pageSize;

  //       // Get the total count of documents in the collection
  //       const totalCount = await taskModel.countDocuments();

  //       taskModel
  //         .find()
  //         .skip(skipCount)
  //         .limit(pageSize)
  //         .exec((err, result) => {
  //           if (err) {
  //             return __res_.out(req, res, {
  //               status: "error",
  //               statusCode: 500,
  //               message: "Unable to Get Data.",
  //               data: null,
  //             });
  //           }

  //           return __res_.out(req, res, {
  //             status: "success",
  //             statusCode: 200,
  //             message: "Get Successfully!!",
  //             data: {
  //               totalRecords: totalCount,
  //               currentPage: page,
  //               pageSize: pageSize,
  //               records: result,
  //             },
  //           });
  //         });
  //     } catch (e) {
  //       return __res_.out(req, res, {
  //         status: true,
  //         statusCode: 500,
  //         message: "Internal server error!!!",
  //         data: e,
  //       });
  //     }
  //   },

  getTaskById: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        taskModel.find({ _id: req.params.id }).exec((err, result) => {
          if (err)
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Get Data.",
              data: null,
            });
          return __res_.out(req, res, {
            status: "success",
            statusCode: 200,
            message: "Get Successfully!!",
            data: result,
          });
        });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  getTaskByEmployeeId: async function (req, res) {
    try {
      const employeeId = req.params.id;

      if (!employeeId) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        const page = parseInt(req.query.page) || 1; // Get the requested page number from query parameter
        const pageSize = 20; // Number of records per page
        const skipCount = (page - 1) * pageSize;

        // Get the total count of documents matching the query
        const totalCount = await taskModel.countDocuments({
          CreatedBy: employeeId,
        });

        taskModel
          .find({ CreatedBy: employeeId })
          .skip(skipCount)
          .limit(pageSize)
          .exec((err, result) => {
            if (err) {
              return __res_.out(req, res, {
                status: "error",
                statusCode: 500,
                message: "Unable to Get Data.",
                data: null,
              });
            }

            return __res_.out(req, res, {
              status: "success",
              statusCode: 200,
              message: "Get Successfully!!",
              data: {
                totalRecords: totalCount,
                currentPage: page,
                pageSize: pageSize,
                records: result,
              },
            });
          });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  deleteTaskById: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        taskModel.deleteOne({ _id: req.params.id }).exec((err, result) => {
          if (err) {
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Delete Role.",
              data: null,
            });
          }
          {
            return __res_.out(req, res, {
              status: "success",
              statusCode: 200,
              message: "Deleted Successfully!!",
            });
          }
        });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  updateTaskById: async function (req, res) {
    try {
      const taskId = req.params.id;
      const updates = req.body;

      if (!taskId) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "Task ID is required.",
          data: null,
        });
      }

      const updatedTask = await taskModel
        .findOneAndUpdate(
          { _id: taskId },
          { $set: { ...updates, updatedAt: new Date() } },
          { new: true }
        )
        .exec();

      if (!updatedTask) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 404,
          message: "Task not found or no changes were made.",
          data: null,
        });
      }

      return __res_.out(req, res, {
        status: "success",
        statusCode: 200,
        message: "Task Updated Successfully!!",
        data: updatedTask,
      });
    } catch (e) {
      return __res_.out(req, res, {
        status: "error",
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
};
