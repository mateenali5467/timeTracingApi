const customerModel = require("../models/customerSchema");
const __res_ = require("../utils/helpers/send-response");

module.exports = {
  createCustomer: async function (req, res) {
    console.log("inside customer");
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        customerModel
          .findOne({ CustomerName: req.body.CustomerName })
          .exec(function (err, userInfo) {
            if (userInfo) {
              return __res_.out(req, res, {
                status: "found",
                statusCode: 200,
                message: "This Customer already exit with this name!!.",
              });
            } else {
              var empData = {
                CustomerName: req.body.CustomerName,
                CreatedBy: req.params.id,
                Notes: req.body.Notes,
                IsActive: req.body.IsActive,
              };
              new customerModel(empData).save().then((data) => {
                if (data) {
                  return __res_.out(req, res, {
                    status: true,
                    statusCode: 200,
                    message: "Customer Created Successfully!!",
                  });
                }
              });
            }
          });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  getAllCustomer: async function (req, res) {
    try {
      const page = parseInt(req.query.page) || 1; // Get the requested page number from query parameter
      const pageSize = 20; // Number of records per page
      const skipCount = (page - 1) * pageSize;

      // Get the total count of documents in the collection
      const totalCount = await customerModel.countDocuments();

      customerModel
        .find()
        .select("_id CustomerName IsActive Notes")
        .skip(skipCount)
        .limit(pageSize)
        .exec((err, result) => {
          if (err) {
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Get Data.",
              data: null,
            });
          }

          return __res_.out(req, res, {
            status: "success",
            statusCode: 200,
            message: "Get Successfully!!",
            data: {
              totalRecords: totalCount,
              currentPage: page,
              pageSize: pageSize,
              records: result,
            },
          });
        });
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },

  getCustonerById: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        customerModel
          .find({ _id: req.params.id })
          .select("_id CustomerName IsActive Notes")
          .exec((err, result) => {
            if (err)
              return __res_.out(req, res, {
                status: "error",
                statusCode: 500,
                message: "Unable to Get Data.",
                data: null,
              });
            return __res_.out(req, res, {
              status: "success",
              statusCode: 200,
              message: "Get Successfully!!",
              data: result,
            });
          });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },

  getCustonerBySuperAdmin: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        const page = parseInt(req.query.page) || 1; // Get the requested page number from query parameter
        const pageSize = 20; // Number of records per page
        const skipCount = (page - 1) * pageSize;

        // Get the total count of documents matching the query
        const totalCount = await customerModel.countDocuments({
          CreatedBy: req.params.id,
        });

        customerModel
          .find({ CreatedBy: req.params.id })
          .skip(skipCount)
          .limit(pageSize)
          .exec((err, result) => {
            if (err) {
              return __res_.out(req, res, {
                status: "error",
                statusCode: 500,
                message: "Unable to Get Data.",
                data: null,
              });
            }

            return __res_.out(req, res, {
              status: "success",
              statusCode: 200,
              message: "Get Successfully!!",
              data: {
                totalRecords: totalCount,
                currentPage: page,
                pageSize: pageSize,
                records: result,
              },
            });
          });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },

  deleteCustomerById: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        customerModel.deleteOne({ _id: req.params.id }).exec((err, result) => {
          if (err) {
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Delete Role.",
              data: null,
            });
          }
          {
            return __res_.out(req, res, {
              status: "success",
              statusCode: 200,
              message: "Deleted Successfully!!",
              data: result,
            });
          }
        });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },

  updateCustomer: async function (req, res) {
    try {
      const customerId = req.params.id;
      const updates = req.body;

      if (!customerId) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "Customer ID is required.",
          data: null,
        });
      }

      const result = await customerModel
        .findOneAndUpdate(
          { _id: customerId },
          { $set: updates, updatedAt: new Date() }
        )
        .exec();

      if (result.nModified === 0) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 404,
          message: "Customer not found or no changes were made.",
          data: null,
        });
      }

      return __res_.out(req, res, {
        status: "success",
        statusCode: 200,
        message: "Customer Updated Successfully!!",
        data: result,
      });
    } catch (e) {
      return __res_.out(req, res, {
        status: "error",
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
};
