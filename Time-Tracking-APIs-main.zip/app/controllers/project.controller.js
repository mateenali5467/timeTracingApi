const projectModel = require("../models/projectSchema");
const __res_ = require("../utils/helpers/send-response");

module.exports = {
  createProject: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        projectModel
          .findOne({ ProjectName: req.body.ProjectName })
          .exec(function (err, userInfo) {
            if (userInfo) {
              return __res_.out(req, res, {
                status: "found",
                statusCode: 200,
                message: "This Project already exit with this name!!.",
              });
            } else {
              var empData = {
                ProjectName: req.body.ProjectName,
                CustomerId: req.body.CustomerId,
                ProjectNumber: req.body.ProjectNumber,
                Notes: req.params.Notes,
                CreatedBy: req.params.id,
              };
              new projectModel(empData).save().then((data) => {
                if (data) {
                  return __res_.out(req, res, {
                    status: true,
                    statusCode: 200,
                    message: "Project Created Successfully!!",
                  });
                }
              });
            }
          });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  getAllProjects: async function (req, res) {
    try {
      const page = parseInt(req.query.page) || 1; // Get the requested page number from query parameter
      const pageSize = 20; // Number of records per page
      const skipCount = (page - 1) * pageSize;

      // Get the total count of documents in the collection
      const totalCount = await projectModel.countDocuments();

      projectModel
        .find()
        .skip(skipCount)
        .limit(pageSize)
        .exec((err, result) => {
          if (err) {
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Get Data.",
              data: null,
            });
          }

          return __res_.out(req, res, {
            status: "success",
            statusCode: 200,
            message: "Get Successfully!!",
            data: {
              totalRecords: totalCount,
              currentPage: page,
              pageSize: pageSize,
              records: result,
            },
          });
        });
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  getProjectsById: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        projectModel.find({ _id: req.params.id }).exec((err, result) => {
          if (err)
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Get Data.",
              data: null,
            });
          return __res_.out(req, res, {
            status: "success",
            statusCode: 200,
            message: "Get Successfully!!",
            data: result,
          });
        });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  deleteProjectsById: async function (req, res) {
    try {
      if (!req.params.id) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "id is required.",
          data: null,
        });
      } else {
        projectModel.deleteOne({ _id: req.params.id }).exec((err, result) => {
          if (err) {
            return __res_.out(req, res, {
              status: "error",
              statusCode: 500,
              message: "Unable to Delete Role.",
              data: null,
            });
          }
          {
            return __res_.out(req, res, {
              status: "success",
              statusCode: 200,
              message: "Deleted Successfully!!",
            });
          }
        });
      }
    } catch (e) {
      return __res_.out(req, res, {
        status: true,
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
  updateProjectById: async function (req, res) {
    try {
      const projectId = req.params.id;
      const updates = req.body;

      if (!projectId) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 400,
          message: "Project ID is required.",
          data: null,
        });
      }

      const updatedProject = await projectModel
        .findOneAndUpdate(
          { _id: projectId },
          { $set: { ...updates, updatedAt: new Date() } },
          { new: true }
        )
        .exec();

      if (!updatedProject) {
        return __res_.out(req, res, {
          status: "error",
          statusCode: 404,
          message: "Project not found or no changes were made.",
          data: null,
        });
      }

      return __res_.out(req, res, {
        status: "success",
        statusCode: 200,
        message: "Project Updated Successfully!!",
        data: updatedProject,
      });
    } catch (e) {
      return __res_.out(req, res, {
        status: "error",
        statusCode: 500,
        message: "Internal server error!!!",
        data: e,
      });
    }
  },
};
